import tkinter as tk
from tkinter import ttk, messagebox
import pandas as pd


class Administracao:
    def __init__(self, root, sistema_vendas):
        self.root = root
        self.sistema_vendas = sistema_vendas

        self.root.title("Administração")

        # Botão para cadastrar novo produto
        ttk.Button(root, text="Cadastrar Novo Produto", command=self.cadastrar_novo_produto).pack(pady=10)
        ttk.Button(root, text="Alterar preço de Produto", command=self.alterar_preco).pack(pady=10)
    def cadastrar_novo_produto(self):
        # Janela para cadastrar novo produto
        cadastrar_produto_window = tk.Toplevel(self.root)
        cadastrar_produto_window.title("Cadastrar Novo Produto")

        # Variáveis para armazenar nome, preço e estoque do novo produto
        nome_produto_var = tk.StringVar()
        preco_produto_var = tk.DoubleVar()
        estoque_produto_var = tk.IntVar()

        # Entradas para nome, preço e estoque do novo produto
        ttk.Label(cadastrar_produto_window, text="Nome do Produto:").pack(pady=5)
        ttk.Entry(cadastrar_produto_window, textvariable=nome_produto_var).pack(pady=5)

        ttk.Label(cadastrar_produto_window, text="Preço do Produto:").pack(pady=5)
        ttk.Entry(cadastrar_produto_window, textvariable=preco_produto_var).pack(pady=5)

        ttk.Label(cadastrar_produto_window, text="Estoque do Produto:").pack(pady=5)
        ttk.Entry(cadastrar_produto_window, textvariable=estoque_produto_var).pack(pady=5)

        # Botão para confirmar o cadastro do novo produto
        ttk.Button(cadastrar_produto_window, text="Cadastrar", command=lambda: self.confirmar_cadastro_produto(
            nome_produto_var.get(), preco_produto_var.get(), estoque_produto_var.get())).pack(pady=10)
        cadastrar_produto_window.pd("Produtos.xlsx")
    def confirmar_cadastro_produto(self, nome, preco, estoque):
        # Adicione a lógica para cadastrar o novo produto no DataFrame e atualizar o Excel
        novo_produto = {'Produto': nome, 'Preço': preco, 'Estoque': estoque}
        self.sistema_vendas.produtos = self.sistema_vendas.produtos.append(novo_produto, ignore_index=True)

        # Atualiza o Excel com os novos dados
        self.sistema_vendas.produtos.to_excel.append('Produtos.xlsx', index=True)
    
        

        messagebox.showinfo("Cadastro de Produto", f"Produto '{nome}' cadastrado com sucesso.")
    def alterar_preco(self):
        # Janela para alterar preço do produto
        alterar_preco_window = tk.Toplevel(self.root)
        alterar_preco_window.title("Alterar Preço de Produto")

        # Variáveis para armazenar nome do produto e novo preço
        nome_produto_var = tk.StringVar()
        novo_preco_var = tk.DoubleVar()

        # Entradas para nome do produto e novo preço
        ttk.Label(alterar_preco_window, text="Nome do Produto:").pack(pady=5)
        ttk.Entry(alterar_preco_window, textvariable=nome_produto_var).pack(pady=5)

        ttk.Label(alterar_preco_window, text="Novo Preço:").pack(pady=5)
        ttk.Entry(alterar_preco_window, textvariable=novo_preco_var).pack(pady=5)

        # Botão para confirmar a alteração do preço do produto
        ttk.Button(alterar_preco_window, text="Alterar", command=lambda: self.confirmar_alteracao_preco(
            nome_produto_var.get(), novo_preco_var.get())).pack(pady=10)

    def confirmar_alteracao_preco(self, nome, novo_preco):
        # Adicione a lógica para alterar o preço do produto no DataFrame e atualizar o Excel
        indice_produto = self.sistema_vendas.produtos[self.sistema_vendas.produtos['Produto'] == nome].index
        self.sistema_vendas.produtos.loc[indice_produto, 'Preço'] = novo_preco

        # Atualiza o Excel com os novos dados
        self.sistema_vendas.produtos.to_excel('Produtos.xlsx', index=True)
    
        
if __name__ == "__main__":
    root = tk.Tk()

    root.mainloop()
