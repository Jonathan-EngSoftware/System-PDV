import tkinter as tk
from tkinter import ttk, messagebox
import pandas as pd
from admin import Administracao
from ttkthemes import ThemedTk  # Importe a classe ThemedTk do ttkthemes

class SistemaVendas:
    def __init__(self, root):
        self.root = root
        self.root.title("Sistema de Vendas")

        # Carregar produtos do Excel
        self.produtos = self.importar_produtos()

        # Inicializar carrinho
        self.carrinho = []

        # Criar um painel para mostrar os itens no carrinho
        self.painel_carrinho = ttk.LabelFrame(root, text="Carrinho")
        self.painel_carrinho.pack(pady=10)

        # Botão para acessar a loja
        ttk.Button(root, text="Acessar Loja", command=self.exibir_loja).pack(pady=10)

        # Adicionar botão de acesso administrativo
        ttk.Button(root, text="Acesso Administrativo", command=self.abrir_janela_login).pack(pady=10)

    def importar_produtos(self):
        try:
            planilha_excel = pd.read_excel('Produtos.xlsx')

            if set(['Produto', 'Preço', 'Estoque']).issubset(planilha_excel.columns):
                return planilha_excel
            else:
                messagebox.showerror("Erro", "A planilha deve conter colunas 'Produto', 'Preço' e 'Estoque'.")
                return pd.DataFrame()

        except Exception as e:
            messagebox.showerror("Erro", f"Erro ao importar produtos: {str(e)}")
            return pd.DataFrame()

    def exibir_loja(self):
        # Janela para a loja
        loja_window = ThemedTk(theme="plastik")  # Use o tema "plastik"
        loja_window.title("Loja")

        # Botões para cada produto na loja
        for index, row in self.produtos.iterrows():
            # Frame para cada produto
            produto_frame = ttk.Frame(loja_window, padding=(10, 5))
            produto_frame.pack(fill=tk.X)

            # Label com informações do produto
            ttk.Label(produto_frame, text=f"{row['Produto']} - R${row['Preço']:.2f}").pack(side=tk.LEFT)

            # Spinbox para selecionar a quantidade
            quantidade_var = tk.IntVar(value=0)
            ttk.Spinbox(produto_frame, from_=0, to=row['Estoque'], textvariable=quantidade_var, width=3).pack(side=tk.LEFT, padx=10)

            # Botão para adicionar ao carrinho
            ttk.Button(produto_frame, text="Adicionar ao Carrinho", command=lambda prod=row['Produto'], price=row['Preço'], qty=quantidade_var: self.adicionar_ao_carrinho(prod, price, qty.get())).pack(side=tk.LEFT)

        # Botão para exibir carrinho
        ttk.Button(loja_window, text="Ver Carrinho", command=self.exibir_carrinho).pack(pady=10)  ttk.Button(produto_frame, text="Adicionar ao Carrinho", command=lambda prod=row['Produto'], price=row['Preço'], qty=quantidade_var: self.adicionar_ao_carrinho(prod, price, qty.get())).pack(side=tk.LEFT)

        # Botão para exibir carrinho
        ttk.Button(loja_window, text="Ver Carrinho", command=self.exibir_carrinho).pack(pady=10)

    def adicionar_ao_carrinho(self, produto, preco, quantidade):
        if quantidade > 0:
            # Adiciona produto ao carrinho
            self.carrinho.append({"Produto": produto, "Preço": preco, "Quantidade": quantidade})
            print(f"{quantidade} {produto}(s) adicionado(s) ao carrinho.")

            # Atualiza o painel de carrinho
            self.atualizar_painel_carrinho()

    def exibir_carrinho(self):
        # Janela para o carrinho
        carrinho_window = tk.Toplevel(self.root)
        carrinho_window.title("Carrinho")

        # Mostra os itens no carrinho
        for item in self.carrinho:
            ttk.Label(carrinho_window, text=f"{item['Quantidade']}x {item['Produto']} - R${item['Preço']:.2f}").pack(pady=5)

        # Botão para finalizar a compra
        ttk.Button(carrinho_window, text="Finalizar Compra", command=self.finalizar_compra).pack(pady=10)

    def finalizar_compra(self):
        # Calcular o total da compra
        total = sum(item['Preço'] * item['Quantidade'] for item in self.carrinho)

        # Limpar carrinho
        self.carrinho = []

        # Atualizar o painel do carrinho
        self.atualizar_painel_carrinho()

        # Mostrar mensagem de compra realizada
        messagebox.showinfo("Compra Concluída com Sucesso.", f"Obrigado e Volte Sempre!\nTotal: R${total:.2f}")

    def atualizar_painel_carrinho(self):
        # Limpa o painel do carrinho
        for widget in self.painel_carrinho.winfo_children():
            widget.destroy()

        # Adiciona os itens ao painel do carrinho
        for index, item in enumerate(self.carrinho):
            ttk.Label(self.painel_carrinho, text=f"{item['Quantidade']}x {item['Produto']} - R${item['Preço']:.2f}").grid(row=index, column=0, pady=5)

    def abrir_janela_login(self):
        login_window = tk.Toplevel(self.root)
        login_window.title("Login Administrativo")
        LoginAdmin(login_window, self)

class LoginAdmin:
    def __init__(self, root, sistema_vendas):
        self.root = root
        self.sistema_vendas = sistema_vendas

        self.root.title("Login Administrativo")

        # Variáveis para armazenar login e senha
        self.login_var = tk.StringVar()
        self.senha_var = tk.StringVar()

        # Entradas para login e senha
        ttk.Label(root, text="Login:").pack(pady=5)
        ttk.Entry(root, textvariable=self.login_var).pack(pady=5)
        ttk.Label(root, text="Senha:").pack(pady=5)
        ttk.Entry(root, textvariable=self.senha_var, show="*").pack(pady=5)

        # Botão para fazer login
        ttk.Button(root, text="Login", command=self.efetuar_login).pack(pady=10)

    def efetuar_login(self):
        # Verifica se as credenciais estão corretas (exemplo simples, não seguro)
        login_correto = "admin"
        senha_correta = "admin123"

        if self.login_var.get() == login_correto and self.senha_var.get() == senha_correta:
            # Fecha a janela de login administrativo
            self.root.destroy()

            # Abre a parte administrativa do sistema
            Administracao(self.sistema_vendas.root, self.sistema_vendas)
        else:
            messagebox.showerror("Erro de Login", "Credenciais incorretas. Tente novamente.")

if __name__ == "__main__":
    # Criar a instância do Tkinter
    root = tk.Tk()

    # Inicializar o Sistema de Vendas
    sistema_vendas = SistemaVendas(root)

    # Configurar tamanho da janela principal
    root.geometry("800x600")

    # Iniciar o loop principal do Tkinter
    root.mainloop()
